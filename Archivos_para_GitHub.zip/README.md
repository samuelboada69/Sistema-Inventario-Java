# Inventario Minimarket — ejemplo de estudio

Java 17 o superior (probado con OpenJDK 21). No requiere dependencias externas.

## IntelliJ IDEA
Abre esta carpeta como proyecto Java, selecciona el JDK, marca `src` como Sources Root y ejecuta `interfaz.Main`.

## Consola
```bash
javac -encoding UTF-8 -d out src/modelo/*.java src/negocio/*.java src/interfaz/*.java
java -cp out interfaz.Main
```
También se puede ejecutar `java -jar InventarioMinimarket.jar`.

## Pruebas
Con Python 3 instalado, después de compilar, ejecuta `python pruebas/ejecutar.py`. Los archivos CP*.txt y CP*.png corresponden a salidas reales de pruebas automatizadas del programa Java, capturadas al mostrar el registro en una terminal. Se ejecutaron el 24-11-2026. El script vuelve a calcular las fechas relativas al día actual.

## GitHub
Crea un repositorio público desde tu cuenta, sube `src`, `pruebas`, `README.md`, `UML.dot`, `UML.png` y `.gitignore`. Copia la URL real en el informe después de verificarla. No hay un repositorio remoto publicado por este ejemplo.

## Alcance
Inventario en memoria, un usuario, costo máximo $500, 1000 unidades, sin persistencia. El precio representa costo de adquisición; cada código identifica un producto/lote. El código y documentación son un ejemplo elaborado con asistencia de ChatGPT; revisa, adapta y declara su uso antes de presentar trabajo propio.
