import subprocess, pathlib, json, datetime, sys, textwrap
ROOT=pathlib.Path(__file__).resolve().parents[1]
D=datetime.date.today(); ingreso=str(D-datetime.timedelta(days=10)); caducidad=str(D-datetime.timedelta(days=1))
def n(c='T01',nombre='Tornillo',cant='10',precio='0.50'):
    return ['1','N',c,nombre,cant,precio,ingreso,'Ferreteria']
def p(): return ['1','P','L01','Leche','4','1.25',ingreso,caducidad]
# Cada prueba arranca con un inventario vacío.
cases=[
('CP1','Cantidad vacía','RF1: Registrar','Rechazar campos obligatorios sin valor.','Cantidad obligatoria.',n(cant='')+['2','0'],['La cantidad es obligatoria.','Sin productos para mostrar.']),
('CP2','Registro válido','RF1: Registrar','Registrar un producto con datos válidos.','Confirmación T01 y 10 unidades.',n()+['2','0'],['Producto registrado: T01','T01 | Tornillo | Cant: 10 | $0.50']),
('CP3','Cantidad negativa','RF1: Registrar','Impedir existencias negativas.','Rechazo y total de cero unidades.',n(cant='-2')+['7','0'],['La cantidad no puede ser negativa.','Total: $0.00 | Unidades: 0']),
('CP4','Código duplicado','RF1: Registrar','Impedir dos registros con el mismo código.','Rechazo; se conservan 10 unidades.',n()+n(c='t01')+['7','0'],['Código duplicado.','Total: $5.00 | Unidades: 10']),
('CP5','Listado','RF2: Listar','Mostrar ambos tipos de producto.','Se muestran T01 y L01 con sus detalles.',n()+p()+['2','0'],['T01 | Tornillo | Cant: 10 | $0.50','L01 | Leche | Cant: 4 | $1.25']),
('CP6','Búsqueda','RF3: Buscar','Consultar un producto existente por código.','Se muestra T01.',n()+['3','T01','0'],['T01 | Tornillo | Cant: 10 | $0.50']),
('CP7','Actualizar cantidad','RF4: Actualizar','Cambiar las unidades de un registro.','T01 pasa de 10 a 15 unidades.',n()+['4','T01','15','3','T01','0'],['Cantidad actualizada.','T01 | Tornillo | Cant: 15 | $0.50']),
('CP8','Eliminar producto','RF5: Eliminar','Retirar un producto del inventario.','Inventario vacío después de eliminar.',n()+['5','T01','2','0'],['Producto eliminado.','Sin productos para mostrar.']),
('CP9','Alerta de caducidad','RF6: Alertas','Detectar un perecedero vencido.','Se muestra L01 con estado CADUCADO.',p()+['6','0'],['L01 | Leche | Cant: 4 | $1.25','CADUCADO']),
('CP10','Valor total','RF7: Total','Sumar el valor de los dos productos.','Total $10.00; 14 unidades.',n()+p()+['7','0'],['Total: $10.00 | Unidades: 14']),
('CP11','Límite de presupuesto','RF1: Registrar','Impedir que el valor supere $500.','Rechazo; inventario vacío.',n(cant='100',precio='6.00')+['7','0'],['Se supera el presupuesto de $500.00.','Total: $0.00 | Unidades: 0']),
('CP12','Límite de capacidad','RF4: Actualizar','Rechazar una actualización superior a 1000 unidades.','Rechazo; quedan 10 unidades.',n(precio='0.10')+['4','T01','1001','7','0'],['Se supera la capacidad de 1000 unidades.','Total: $1.00 | Unidades: 10']),
('CP13','Precio inválido','RF1: Registrar','Rechazar un precio igual a cero.','Error de precio; inventario vacío.',n(precio='0')+['7','0'],['El precio debe ser positivo','Total: $0.00 | Unidades: 0']),
('CP14','Fecha incoherente','RF1: Registrar','Rechazar caducidad anterior a ingreso.','Error de fechas; inventario vacío.', ['1','P','L01','Leche','4','1.25',ingreso,str(D-datetime.timedelta(days=11)),'7','0'],['Caducidad anterior al ingreso.','Total: $0.00 | Unidades: 0'])]

def run(case):
    id,title,rf,desc,expected,inputs,checks=case
    result=subprocess.run(['java','-cp',str(ROOT/'out'),'interfaz.Main'],input='\n'.join(inputs)+'\n',text=True,capture_output=True)
    ok=result.returncode==0 and all(c in result.stdout for c in checks)
    # Salida original del proceso, sin inventar mensajes ni modificar resultados.
    log=f'{id} - {title}\nFecha de ejecución: {D}\nEntrada (orden real de líneas):\n'
    log+='\n'.join(textwrap.wrap(' | '.join(x or '[VACÍO]' for x in inputs), 99))+'\n\nSalida real de Java:\n'+result.stdout+result.stderr+'\nVerificación: '+('APROBADO' if ok else 'FALLIDO')+'\n'
    return dict(id=id,title=title,rf=rf,desc=desc,expected=expected,inputs=inputs,checks=checks,ok=ok,stdout=result.stdout,log=log)
if __name__=='__main__':
    results=[run(c) for c in cases if len(sys.argv)==1 or c[0]==sys.argv[1]]
    for r in results: print(r['log'])
    if len(sys.argv)==1:
        (ROOT/'pruebas'/'resultados.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    sys.exit(0 if all(r['ok'] for r in results) else 1)
